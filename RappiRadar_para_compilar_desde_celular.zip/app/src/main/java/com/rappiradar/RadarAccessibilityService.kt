package com.rappiradar

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class RadarAccessibilityService : AccessibilityService() {
    private var overlay: RadarOverlay? = null
    private var previous = ""

    override fun onServiceConnected() { overlay = RadarOverlay(this) }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val pkg = event.packageName?.toString()?.lowercase() ?: return
        if (!pkg.contains("rappi")) return
        val root = rootInActiveWindow ?: return
        val out = StringBuilder()
        collect(root, out)
        val content = out.toString()
        if (content.isBlank() || content == previous) return
        previous = content
        OrderAnalyzer.analyze(content)?.let { overlay?.show(it) }
    }

    private fun collect(node: AccessibilityNodeInfo?, out: StringBuilder) {
        if (node == null || out.length > 12000) return
        node.text?.toString()?.takeIf { it.isNotBlank() }?.let { out.append(it).append(' ') }
        node.contentDescription?.toString()?.takeIf { it.isNotBlank() }?.let { out.append(it).append(' ') }
        for (i in 0 until node.childCount) collect(node.getChild(i), out)
    }

    override fun onInterrupt() {}
    override fun onDestroy() { overlay?.remove(); super.onDestroy() }
}
