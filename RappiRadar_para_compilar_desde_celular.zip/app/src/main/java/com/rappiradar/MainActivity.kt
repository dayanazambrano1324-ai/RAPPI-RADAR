package com.rappiradar

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 24)
        }
        layout.addView(TextView(this).apply { text = "Rappi Radar"; textSize = 28f })
        layout.addView(TextView(this).apply {
            text = "Clasifica ofertas según pago por kilómetro. En pedidos adicionales usa 'Ganancia por pedido adicional', no el total combinado de la ruta."
            textSize = 16f
        })
        layout.addView(Button(this).apply {
            text = "1. Permitir burbuja flotante"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity))
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        })
        layout.addView(Button(this).apply {
            text = "2. Activar lectura de pantalla"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        layout.addView(Button(this).apply {
            text = "Probar ejemplo"
            setOnClickListener {
                OrderAnalyzer.analyze("PEDIDO ADICIONAL Se agregará a tu ruta en curso $16,500 +2.0 km Ganancia por pedido adicional $9,950")
                    ?.let { RadarOverlay(this@MainActivity).show(it) }
            }
        })
        layout.addView(TextView(this).apply {
            text = "Prototipo experimental. La lectura automática solo funcionará si Rappi expone estos datos como texto accesible. Si la oferta aparece como imagen, habrá que incorporar captura de pantalla autorizada y OCR. No acepta ni rechaza pedidos."
            textSize = 13f
        })
        setContentView(layout)
    }
}
