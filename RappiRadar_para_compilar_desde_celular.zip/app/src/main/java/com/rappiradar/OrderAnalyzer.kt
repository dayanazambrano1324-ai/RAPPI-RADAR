package com.rappiradar

data class Analysis(
    val amount: Int,
    val km: Double,
    val perKm: Int,
    val rating: Rating,
    val additional: Boolean,
    val deliveryType: String
)
enum class Rating { BAD, GOOD, EXCELLENT }

object OrderAnalyzer {
    private val money = Regex("""\$\s*([\d.,]+)""")
    private val km = Regex("""(\d+(?:[.,]\d+)?)\s*km\b""", RegexOption.IGNORE_CASE)

    private fun pesos(s: String): Int? = s.filter { it.isDigit() }.toIntOrNull()

    private fun parseAmount(text: String): Int? {
        // Rappi may label the incremental pay in different ways.
        val labels = listOf(
            Regex("""ganancia\s+por\s+pedido\s+adicional\s*\$?\s*([\d.,]+)""", RegexOption.IGNORE_CASE),
            Regex("""ganancia\s+adicional(?:\s+por\s+este\s+pedido)?\s*\$?\s*([\d.,]+)""", RegexOption.IGNORE_CASE),
            Regex("""(?:vas\s+a\s+)?ganar\s+adicional(?:\s+por\s+este\s+pedido)?\s*\$?\s*([\d.,]+)""", RegexOption.IGNORE_CASE),
            Regex("""valor\s+adicional(?:\s+de)?\s*\$?\s*([\d.,]+)""", RegexOption.IGNORE_CASE),
            Regex("""adicional\s+por\s+este\s+pedido\s*\$?\s*([\d.,]+)""", RegexOption.IGNORE_CASE)
        )
        for (pattern in labels) {
            val found = pattern.find(text)?.groupValues?.getOrNull(1)
            if (found != null) return pesos(found)
        }
        return null
    }

    fun analyze(raw: String): Analysis? {
        val text = raw.replace('\u00a0', ' ')
        val isAdditional = text.contains("PEDIDO ADICIONAL", true) ||
            text.contains("se agregará a tu ruta", true) ||
            text.contains("entrega en la ruta", true) ||
            text.contains("ganancia adicional", true) ||
            text.contains("ganar adicional", true)

        val distance = km.findAll(text).mapNotNull {
            it.groupValues[1].replace(",", ".").toDoubleOrNull()
        }.firstOrNull { it > 0.0 } ?: return null

        // Prefer the explicitly stated incremental amount for double/triple additions.
        // Never substitute the combined route total when the offer is an addition.
        val additionalAmount = if (isAdditional) parseAmount(text) else null
        val amount = additionalAmount
            ?: if (!isAdditional) money.find(text)?.groupValues?.get(1)?.let { pesos(it) } else null
            ?: return null

        if (amount !in 500..500_000) return null
        val rate = (amount / distance).toInt()
        val rating = when {
            rate < 2000 -> Rating.BAD
            rate < 3000 -> Rating.GOOD
            else -> Rating.EXCELLENT
        }
        val type = when {
            text.contains("tripleta", true) || text.contains("3 entregas", true) -> "TRIPLETA"
            text.contains("doblete", true) || text.contains("2 entregas", true) -> "DOBLETE"
            isAdditional -> "ADICIONAL"
            else -> "INDIVIDUAL"
        }
        return Analysis(amount, distance, rate, rating, isAdditional, type)
    }
}
