package com.rappiradar

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView

class RadarOverlay(private val context: Context) {
    private val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var bubble: TextView? = null

    fun show(a: Analysis) {
        val color = when (a.rating) {
            Rating.BAD -> Color.rgb(190, 35, 45)
            Rating.GOOD -> Color.rgb(205, 135, 20)
            Rating.EXCELLENT -> Color.rgb(25, 135, 75)
        }
        val label = when (a.rating) {
            Rating.BAD -> "MALO"
            Rating.GOOD -> "BUENO"
            Rating.EXCELLENT -> "EXCELENTE"
        }
        val v = TextView(context).apply {
            text = "$label\\n$${"%,d".format(a.perKm)}/km"
            textSize = 15f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(22, 14, 22, 14)
            background = GradientDrawable().apply { setColor(color); cornerRadius = 28f }
        }
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = 16; y = 180 }
        remove()
        bubble = v
        wm.addView(v, p)
    }

    fun remove() {
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bubble = null
    }
}
